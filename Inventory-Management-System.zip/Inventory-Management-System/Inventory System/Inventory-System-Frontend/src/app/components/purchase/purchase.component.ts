import { Component, OnInit } from '@angular/core';
import { PurchaseService } from '../../services/purchase.service';
import { ProductService } from '../../services/product.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FilterByNamePipe } from '../../pipes/filter-by-name.pipe';

import { Purchase } from '../../interfaces/Ipurchase';
import { Product } from '../../interfaces/Iproduct';
import { EnrichedRecord } from '../../interfaces/IenrichedProduct';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, FilterByNamePipe],
})
export class PurchaseComponent implements OnInit {
  purchases: Purchase[] = [];
  enrichedPurchases: EnrichedRecord<Purchase>[] = [];
  products: Product[] = [];
  purchaseForm: FormGroup;
  searchTerm: string = '';

  constructor(
    private purchaseService: PurchaseService,
    private productService: ProductService,
    private fb: FormBuilder
  ) {
    this.purchaseForm = this.fb.group({
      productId: ['', Validators.required],
      quantityPurchased: [0, [Validators.required, Validators.min(1)]],
      purchaseDate: [new Date(), Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadPurchases();
    this.loadProducts();
  }

  loadPurchases(): void {
    this.purchaseService.getPurchases().subscribe(data => {
      this.purchases = data;
      this.enrich();
    });
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe(data => {
      this.products = data;
      this.enrich();
    });
  }

  enrich(): void {
    if (!this.purchases.length || !this.products.length) return;
    this.enrichedPurchases = this.enrichRecords<Purchase>(this.purchases, this.products);
  }

  recordPurchase(): void {
    if (this.purchaseForm.invalid) {
      this.purchaseForm.markAllAsTouched();
      return;
    }

    const purchaseData = this.purchaseForm.value;

    if (purchaseData.quantityPurchased < 0) {
      purchaseData.quantityPurchased = 0;
    }

    this.purchaseService.addPurchase(purchaseData).subscribe(() => {
      this.loadPurchases();
      this.loadProducts();
      this.purchaseForm.reset({ purchaseDate: new Date() });
    }, error => console.error('Error recording purchase:', error));
  }

  // ✅ Generic reusable enrich function
  enrichRecords<T extends { productId: number }>(records: T[], products: Product[]): EnrichedRecord<T>[] {
    return records.map(record => {
      const matched = products.find(p => p.id === record.productId);
      return {
        ...record,
        productName: matched ? matched.name : 'Unknown Product'
      };
    });
  }
}
