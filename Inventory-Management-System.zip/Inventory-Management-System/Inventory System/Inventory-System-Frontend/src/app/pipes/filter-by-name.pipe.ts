// import { Pipe, PipeTransform } from '@angular/core';

// @Pipe({
//   name: 'filterByName'
// })
// // export class FilterByNamePipe implements PipeTransform {
// //   transform(products: any[], searchTerm: string): any[] {
// //     if (!searchTerm) return products;
// //     const lower = searchTerm.toLowerCase();
// //     return products.filter(p => p.name?.toLowerCase().includes(lower));
// //   }
// // }
// export class FilterByNamePipe implements PipeTransform {
//   transform(items: any[], searchTerm: string): any[] {
//     if (!searchTerm) return items;
//     const lower = searchTerm.toLowerCase();
//     return items.filter(item => item.productName?.toLowerCase().includes(lower));
//   }  
// }
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterByName'
})
export class FilterByNamePipe implements PipeTransform {
  transform(items: any[], searchTerm: string, keys: string | string[]): any[] {
    if (!searchTerm || !keys) return items;

    const search = searchTerm.toLowerCase();
    const keyArray = Array.isArray(keys) ? keys : [keys];

    return items.filter(item =>
      keyArray.some(key => item[key]?.toString().toLowerCase().includes(search))
    );
  }
}
