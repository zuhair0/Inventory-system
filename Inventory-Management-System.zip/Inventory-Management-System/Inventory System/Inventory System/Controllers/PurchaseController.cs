﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory_System.DBcontext;
using Inventory_System.Models;

namespace Inventory_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PurchaseController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Purchase
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Purchase>>> GetPurchases()
        {
            return await _context.Purchases.Include(p => p.Product).ToListAsync();
        }

        // GET: api/Purchase/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Purchase>> GetPurchase(int id)
        {
            var purchase = await _context.Purchases.Include(p => p.Product).FirstOrDefaultAsync(p => p.Id == id);

            if (purchase == null)
            {
                return NotFound();
            }

            return purchase;
        }

        // POST: api/Purchase
        [HttpPost]
        public async Task<ActionResult<Purchase>> PostPurchase([FromBody] PurchaseDto purchaseDto)
        {
            var product = await _context.Products.FindAsync(purchaseDto.ProductId);

            if (product == null)
            {
                return NotFound("Product not found");
            }

            var purchase = new Purchase
            {
                ProductId = purchaseDto.ProductId,
                QuantityPurchased = purchaseDto.QuantityPurchased,
                PurchaseDate = purchaseDto.PurchaseDate
            };

            // Update inventory (increase quantity)
            product.Quantity += purchaseDto.QuantityPurchased;
            _context.Products.Update(product); // Explicitly update the product
            _context.Purchases.Add(purchase);
            await _context.SaveChangesAsync();

            // Return the purchase with the updated product
            var createdPurchase = await _context.Purchases.Include(p => p.Product).FirstOrDefaultAsync(p => p.Id == purchase.Id);
            return CreatedAtAction(nameof(GetPurchase), new { id = createdPurchase.Id }, createdPurchase);
        }

        // PUT: api/Purchase/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPurchase(int id, Purchase purchase)
        {
            if (id != purchase.Id)
            {
                return BadRequest();
            }

            _context.Entry(purchase).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PurchaseExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Purchase/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePurchase(int id)
        {
            var purchase = await _context.Purchases.FindAsync(id);
            if (purchase == null)
            {
                return NotFound();
            }

            _context.Purchases.Remove(purchase);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PurchaseExists(int id)
        {
            return _context.Purchases.Any(e => e.Id == id);
        }
    }

    public class PurchaseDto
    {
        public int ProductId { get; set; }
        public int QuantityPurchased { get; set; }
        public DateTime PurchaseDate { get; set; }
    }
}