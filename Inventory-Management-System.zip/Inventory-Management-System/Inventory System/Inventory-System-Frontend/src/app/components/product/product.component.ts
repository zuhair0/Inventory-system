import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { FilterByNamePipe } from '../../pipes/filter-by-name.pipe';
import { Product } from '../../interfaces/Iproduct';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FilterByNamePipe, FormsModule]
})
export class ProductComponent implements OnInit {
  products: Product[] = [];
  selectedProduct: Product | null = null;
  productForm: FormGroup;
  searchTerm: string = '';

  constructor(
    private productService: ProductService,
    private fb: FormBuilder
  ) {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      quantity: [0, [Validators.required, Validators.min(1)]],
    });
  }

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe((data: Product[]) => {
      this.products = data;
    });
  }

  deleteProduct(id: number): void {
    this.productService.deleteProduct(id).subscribe(() => {
      this.loadProducts();
    });
  }

  onSubmit(): void {
    if (this.productForm.invalid) {
      this.productForm.markAllAsTouched();
      return;
    }

    const formValue = this.productForm.value as Omit<Product, 'id'>;

    if (formValue.quantity < 0) {
      formValue.quantity = 0;
    }

    if (this.selectedProduct) {
      const updatedProduct: Product = {
        ...formValue,
        id: this.selectedProduct.id
      };

      this.productService.updateProduct(this.selectedProduct.id, updatedProduct).subscribe(() => {
        this.loadProducts();
        this.selectedProduct = null;
        this.productForm.reset();
      });
    } else {
      this.productService.addProduct(formValue).subscribe(() => {
        this.loadProducts();
        this.productForm.reset();
      });
    }
  }

  editProduct(product: Product): void {
    this.selectedProduct = { ...product };
    this.productForm.patchValue({
      name: product.name,
      description: product.description,
      quantity: product.quantity
    });
  }
}
