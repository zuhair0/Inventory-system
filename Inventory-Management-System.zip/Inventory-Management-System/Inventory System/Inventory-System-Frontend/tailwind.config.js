/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}", // Correct the path to point to the src folder
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
