﻿namespace Inventory_System.Models
{
    public class Purchase
    {
        public int Id { get; set; }  // Primary Key
        public int ProductId { get; set; }  // Foreign Key to Product
        public int QuantityPurchased { get; set; }
        public DateTime PurchaseDate { get; set; }

        // Navigation property to link Purchase to Product
        public Product Product { get; set; }
    }
}
