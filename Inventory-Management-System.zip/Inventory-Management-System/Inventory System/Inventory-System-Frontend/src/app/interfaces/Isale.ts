import { Product } from "./Iproduct";

export interface Sale {
    id: number;
    productId: number;
    product?: Product;       // optional: only if populated
    quantitySold: number;
    saleDate: string | Date;
  }
  