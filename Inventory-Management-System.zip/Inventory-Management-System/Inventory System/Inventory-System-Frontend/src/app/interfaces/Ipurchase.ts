import { Product } from "./Iproduct";

export interface Purchase {
    id: number;
    productId: number;
    product?: Product;       // optional: only if populated
    quantityPurchased: number;
    purchaseDate: string | Date;
  }
  