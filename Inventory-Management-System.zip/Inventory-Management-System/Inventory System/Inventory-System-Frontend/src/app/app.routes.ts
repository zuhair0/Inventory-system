import { Routes } from '@angular/router';
import { ProductComponent } from './components/product/product.component';
import { SaleComponent } from './components/sale/sale.component';
import { PurchaseComponent } from './components/purchase/purchase.component';

export const appRoutes: Routes = [
  {
    path: '',
    redirectTo: 'products',
    pathMatch: 'full'
  },
  {
    path: 'products',
    loadComponent: () =>
      import('./components/product/product.component').then(m => m.ProductComponent),
  },
  {
    path: 'sales',
    loadComponent: () =>
      import('./components/sale/sale.component').then(m => m.SaleComponent),
  },
  {
    path: 'purchases',
    loadComponent: () =>
      import('./components/purchase/purchase.component').then(m => m.PurchaseComponent),
  },
];
