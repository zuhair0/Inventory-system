﻿namespace Inventory_System.Models
{
    public class Sale
    {
        public int Id { get; set; }  // Primary Key
        public int ProductId { get; set; }  // Foreign Key to Product
        public int QuantitySold { get; set; }
        public DateTime SaleDate { get; set; }

        // Navigation property to link Sale to Product
        public Product Product { get; set; }
    }
}
