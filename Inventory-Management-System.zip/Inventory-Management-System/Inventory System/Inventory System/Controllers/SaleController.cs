﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Inventory_System.DBcontext;
using Inventory_System.Models;

namespace Inventory_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SaleController : ControllerBase
    {
        private readonly AppDbContext _context;

        public SaleController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Sale
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Sale>>> GetSales()
        {
            return await _context.Sales.Include(s => s.Product).ToListAsync();
        }

        // GET: api/Sale/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Sale>> GetSale(int id)
        {
            var sale = await _context.Sales.Include(s => s.Product).FirstOrDefaultAsync(s => s.Id == id);

            if (sale == null)
            {
                return NotFound();
            }

            return sale;
        }

        // POST: api/Sale
        [HttpPost]
        public async Task<ActionResult<Sale>> PostSale([FromBody] SaleDto saleDto)
        {
            var product = await _context.Products.FindAsync(saleDto.ProductId);

            if (product == null)
            {
                return NotFound("Product not found");
            }

            if (product.Quantity < saleDto.QuantitySold)
            {
                return BadRequest("Not enough stock available");
            }

            var sale = new Sale
            {
                ProductId = saleDto.ProductId,
                QuantitySold = saleDto.QuantitySold,
                SaleDate = saleDto.SaleDate
            };

            // Update inventory
            product.Quantity -= saleDto.QuantitySold;
            _context.Products.Update(product); // Explicitly update the product
            _context.Sales.Add(sale);
            await _context.SaveChangesAsync();

            // Return the sale with the updated product
            var createdSale = await _context.Sales.Include(s => s.Product).FirstOrDefaultAsync(s => s.Id == sale.Id);
            return CreatedAtAction(nameof(GetSale), new { id = createdSale.Id }, createdSale);
        }

        // PUT: api/Sale/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSale(int id, Sale sale)
        {
            if (id != sale.Id)
            {
                return BadRequest();
            }

            _context.Entry(sale).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SaleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Sale/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSale(int id)
        {
            var sale = await _context.Sales.FindAsync(id);
            if (sale == null)
            {
                return NotFound();
            }

            _context.Sales.Remove(sale);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SaleExists(int id)
        {
            return _context.Sales.Any(e => e.Id == id);
        }
    }

    public class SaleDto
    {
        public int ProductId { get; set; }
        public int QuantitySold { get; set; }
        public DateTime SaleDate { get; set; }
    }
}