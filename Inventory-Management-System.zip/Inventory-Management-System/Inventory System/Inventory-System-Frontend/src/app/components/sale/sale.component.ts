import { Component, OnInit } from '@angular/core';
import { SaleService } from '../../services/sale.service';
import { ProductService } from '../../services/product.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FilterByNamePipe } from '../../pipes/filter-by-name.pipe';

import { Sale } from '../../interfaces/Isale';
import { Product } from '../../interfaces/Iproduct';
import { EnrichedRecord } from '../../interfaces/IenrichedProduct';

@Component({
  selector: 'app-sale',
  templateUrl: './sale.component.html',
  styleUrls: ['./sale.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, FilterByNamePipe],
})
export class SaleComponent implements OnInit {
  sales: Sale[] = [];
  enrichedSales: EnrichedRecord<Sale>[] = [];
  products: Product[] = [];
  saleForm: FormGroup;
  searchTerm: string = '';

  constructor(
    private saleService: SaleService,
    private productService: ProductService,
    private fb: FormBuilder
  ) {
    this.saleForm = this.fb.group({
      productId: ['', Validators.required],
      quantitySold: [0, [Validators.required, Validators.min(1)]],
      saleDate: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadSales();
    this.loadProducts();
  }

  loadSales(): void {
    this.saleService.getSales().subscribe((data) => {
      this.sales = data;
      this.enrich();
    });
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe((data) => {
      this.products = data;
      this.enrich();
    });
  }

  enrich(): void {
    if (!this.sales.length || !this.products.length) return;
    this.enrichedSales = this.enrichRecords<Sale>(this.sales, this.products);
  }

  recordSale(): void {
    if (this.saleForm.invalid) {
      this.saleForm.markAllAsTouched();
      return;
    }

    const saleData = this.saleForm.value;

    if (saleData.quantitySold < 1) {
      saleData.quantitySold = 1;
    }

    this.saleService.addSale(saleData).subscribe(
      () => {
        this.loadSales();
        this.loadProducts();
        this.saleForm.reset({ saleDate: new Date() });
      },
      (error) => {
        alert(`Error recording sale: ${error.error}`);
      }
    );
  }

  enrichRecords<T extends { productId: number }>(records: T[], products: Product[]): EnrichedRecord<T>[] {
    return records.map(record => {
      const matched = products.find(p => p.id === record.productId);
      return {
        ...record,
        productName: matched ? matched.name : 'Unknown Product'
      };
    });
  }
}
