import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';  // <-- Import HttpClient
import { RouterModule, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  imports: [RouterOutlet, CommonModule, RouterModule],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private http: HttpClient) { }
  mobileMenuOpen: boolean = false;

  ngOnInit() {
    // Example API call
    // this.http.get('https://your-backend-api-url/products').subscribe(data => {
    //   console.log(data);  // Handle the data
    // });
  }
}
