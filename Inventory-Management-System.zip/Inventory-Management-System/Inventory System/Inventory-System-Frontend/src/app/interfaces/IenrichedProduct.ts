export type EnrichedRecord<T> = T & { productName: string };
